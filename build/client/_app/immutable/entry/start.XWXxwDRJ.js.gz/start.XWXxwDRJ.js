import{l as o,d as r}from"../chunks/cASs5BBf.js";export{o as load_css,r as start};
